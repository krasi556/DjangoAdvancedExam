from django.contrib import messages
from django.contrib.auth.decorators import permission_required, login_required
from django.core.paginator import Paginator
from django.db.models import Avg
from django.http import HttpResponse, HttpResponseForbidden
from django.shortcuts import render, get_object_or_404, redirect

from employees.models import Employee
from reviews.forms import ReviewForms, CreateReview, EditReview, DeleteReview
from reviews.models import Review


# Create your views here.

def show_employees_for_review(request):
    all_employees = Employee.objects.all().order_by('id')
    form = ReviewForms()
    paginator = Paginator(all_employees, 1)
    page = request.GET.get('page')
    page_obj = paginator.get_page(page)
    context = {
        'employees': page_obj,
        'form': form
    }
    return render(request, 'reviews/review-employees.html', context)

@login_required
def leave_review(request, employee_id):
    employee = get_object_or_404(Employee.objects.prefetch_related('reviews'), id=employee_id)
    form = CreateReview(request.POST or None)
    if request.method == 'POST':
        form.instance.author = request.user if request.user.is_authenticated else None
        if form.is_valid():
            review = form.save(commit=False)
            review.employee = employee
            review.save()
            return redirect('employees:focused-employee', pk=employee.id)
    context = {
        'employee': employee,
        'form': form
    }
    return render(request, 'reviews/review-details.html', context)


def current_employee_reviews(request, employee_id):
    get_employee = get_object_or_404(
        Employee.objects
        .annotate(avg_rating=Avg('reviews__rating'))
        .prefetch_related('reviews'),
        id=employee_id)
    context = {
        'employee': get_employee,
        'reviews': get_employee.reviews.all()
    }

    return render(request, 'reviews/show-reviews-for-current-employee.html', context)


def change_employee_permission(permission):
    def decorator(edit_review):
        def wrapp(request, review_id):
            if not request.user.has_perm(permission):
                messages.error(request, 'You got no permission')
                return redirect('core:redirect-home')
            return edit_review(request, review_id)

        return wrapp

    return decorator

@login_required
@change_employee_permission('reviews.can_edit_views')
def edit_review(request, review_id):
    user = request.user
    review = get_object_or_404(Review, id=review_id)
    form = EditReview(request.POST or None, instance=review)
    if request.method == 'POST' and form.is_valid():
        form.save()
        return redirect('employees:focused-employee', pk=review.employee_id)
    context = {
        'form': form,
        'employee': review.employee,
        'review': review
    }
    return render(request, 'reviews/edit-review.html', context)


def delete_review(request, review_id):
    review = get_object_or_404(Review, id=review_id)
    form = DeleteReview(request.POST or None, instance=review)
    if request.method == 'POST' and form.is_valid():
        review.delete()
        return redirect('reviews:current-employee-reviews', review.employee_id)
    context = {
        'form': form,
        'review': review,
        'employee': review.employee,
    }
    return render(request, 'reviews/delete-review.html', context)
