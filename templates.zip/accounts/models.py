from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models

# Create your models here.


class User(AbstractUser):
    pass


class Profile(models.Model):
    user = models.OneToOneField(
        to=settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        primary_key=True,

    )
    first_name = models.CharField(max_length=100,blank=True)
    last_name=models.CharField(max_length=100,blank=True)
    bio = models.TextField(null=True)
    date_of_birth = models.DateField(
        null=True,
        blank=True
    )
    profile_pic = models.ImageField(
        null=True,
        blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)
    rating = models.PositiveIntegerField(default=0)
