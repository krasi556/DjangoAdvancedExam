from django.contrib.auth.forms import UserCreationForm
from django.forms.fields import EmailField

from accounts.models import User


class RegisterForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = User
        fields = ['username', 'email', 'password1', 'password2']

